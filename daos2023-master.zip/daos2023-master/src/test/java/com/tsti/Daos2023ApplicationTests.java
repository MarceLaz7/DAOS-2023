package com.tsti;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Daos2023ApplicationTests {

	@Test
	void contextLoads() {
	}

}
