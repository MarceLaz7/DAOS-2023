package com.tsti.dto;

public class CotizacionDolar {
	private String compra;
	private String venta;
	private String agencia;
	private String nombre;
	private String variacion;
	private String ventaCero;
	private String decimales;
	private String mejor_compra;
	private String mejor_venta;
	private String fecha;
	private String recorrido;
	
	public String getCompra() {
		return compra;
	}
	public void setCompra(String compra) {
		this.compra = compra;
	}
	public String getVenta() {
		return venta;
	}
	public void setVenta(String venta) {
		this.venta = venta;
	}
	public String getAgencia() {
		return agencia;
	}
	public void setAgencia(String agencia) {
		this.agencia = agencia;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getVariacion() {
		return variacion;
	}
	public void setVariacion(String variacion) {
		this.variacion = variacion;
	}
	public String getVentaCero() {
		return ventaCero;
	}
	public void setVentaCero(String ventaCero) {
		this.ventaCero = ventaCero;
	}
	public String getDecimales() {
		return decimales;
	}
	public void setDecimales(String decimales) {
		this.decimales = decimales;
	}
	public String getMejor_compra() {
		return mejor_compra;
	}
	public void setMejor_compra(String mejor_compra) {
		this.mejor_compra = mejor_compra;
	}
	public String getMejor_venta() {
		return mejor_venta;
	}
	public void setMejor_venta(String mejor_venta) {
		this.mejor_venta = mejor_venta;
	}
	public String getFecha() {
		return fecha;
	}
	public void setFecha(String fecha) {
		this.fecha = fecha;
	}
	public String getRecorrido() {
		return recorrido;
	}
	public void setRecorrido(String recorrido) {
		this.recorrido = recorrido;
	}

}
