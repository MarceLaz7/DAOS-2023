package com.tsti.dto;

public class TipoCambioDolar {
	 private CotizacionDolar casa;

	public CotizacionDolar getCasa() {
		return casa;
	}

	public void setCasa(CotizacionDolar casa) {
		this.casa = casa;
	}
	 
}
